package com.example.jikook.vone;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;


public class QuizFundamental extends AppCompatActivity {
    //this is the actual mcq quiz class (topic 1 - fundamental)

    //this class has same logic with the QuizException class. See QuizException in line comment for explaination.

    TextView mark;  // display the current mark
    TextView question;  // /display the current question
    Button ansA; Button ansB; Button ansC; Button ansD;  //button for options
    Button next; //next question button
    Button quitBtn;  //return menu button to return to topic selection page
    Intent intent;
    TextView feedback; // display each question feedback
    TextView result; // used to display final result at the end
    TextView qno;   //keep track of question no.
    ImageView correct;
    ImageView wrong;
    ArrayList<Question> myQuestionBank;
    int score = 0;
    int questionNo = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mcq);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        result = findViewById(R.id.result);
        mark = findViewById(R.id.mark);
        feedback = findViewById(R.id.feedback);
        question = findViewById(R.id.questionBox);
        quitBtn = findViewById(R.id.quitBtn);
        quitBtn.setVisibility(View.INVISIBLE);
        next = findViewById(R.id.next);
        next.setVisibility(View.INVISIBLE);
        correct = findViewById(R.id.correct);
        correct.setVisibility(View.INVISIBLE);
        wrong = findViewById(R.id.wrong);
        wrong.setVisibility(View.INVISIBLE);
        qno = findViewById(R.id.qno);

        myQuestionBank = new ArrayList();
        myQuestionBank.add(new Question("Can a class have no constructor?", "Yes", "If a class does not have constructor, Java will define an empty constructor","No","Yes","",""));
        myQuestionBank.add(new Question("Which of the followings is not an OOP concept?", "Extraction", "There's only encapsulation", "Extraction","Encapsulation","Poloymorphism","Abstraction"));
        myQuestionBank.add(new Question("Which of the followings is not primitive data type", "String", "String is reference data type!.", "integer","String","double","float"));
        myQuestionBank.add(new Question("What will be printed? int a = 11; a++; System.out.println(a);","12","Because 'a' was increased by 1.","10","11","12","Compile Error"));
        myQuestionBank.add(new Question("Choose the correct code fragment that will assign a value of 20 to 'myInt'", "int myInt = 20;", "Assignment should be in the form of: dataType variableName = value;", "20 = myInt int;","myInt int = 20;","int myInt = 20;","None of the above"));
        myQuestionBank.add(new Question("What are the benefits of encapsulation?", "Data Protection", "Encapsulation is done by setting attributes as private. So other class cannot access it without getters and setters.", "Code reusability","Data Protection","Extends classes","Define common behaviors"));
        myQuestionBank.add(new Question("Which class is the subclass of the following code fragment 'public class Dog extends Animals{}'","Dogs","format: modifier class Subclass extends Superclass.","Animals","Dogs","class","None of the above"));
        myQuestionBank.add(new Question("How many class(es) can a class extends the MOST?", "One", "Each class can only extends one class at a time", "No limit","One","Two","Ten"));
        myQuestionBank.add(new Question("See the following code fragment: System.out.println(5 + \"15\"); What is the output?", "515","The numeric value is concatenate with the String! ", "20", "515","5 15","Compile error"));
        myQuestionBank.add(new Question("Which of these is Java error type?","All of the Above","Because a was increased by 1.","Compile error","Runtime Error","Syntax Error","All of the Above"));
        myQuestionBank.add(new Question("What is the output of this code: for(int count = 0; count < 5; count++) {System.out.print(count);}", "01234", "The loop stops before count get to 5", "count","01234","012345","Infinite Loop"));

        Collections.shuffle(myQuestionBank);

        question.setText(myQuestionBank.get(questionNo).getQuestion());
        qno.setText(Integer.toString(questionNo));
        mark.setText(Integer.toString(score));
        ansA = findViewById(R.id.ansA);
        ansA.setText(myQuestionBank.get(questionNo).getA());
        ansB = findViewById(R.id.ansB);
        ansB.setText(myQuestionBank.get(questionNo).getB());
        ansC = findViewById(R.id.ansC);
        ansC.setText(myQuestionBank.get(questionNo).getC());
        ansD = findViewById(R.id.ansD);
        ansD.setText(myQuestionBank.get(questionNo).getD());
         //above codes are just all set up




        ansA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myQuestionBank.get(questionNo).getAnswer().equals(ansA.getText().toString())) {
                    score += 10;
                    mark.setText(Integer.toString(score));
                    feedback.setVisibility(View.VISIBLE);
                    feedback.setText("Correct!!!");
                    correct.setVisibility(View.VISIBLE);
                    next.setVisibility(View.VISIBLE);
                    ansA.setVisibility(View.INVISIBLE);
                    ansB.setVisibility(View.INVISIBLE);
                    ansC.setVisibility(View.INVISIBLE);
                    ansD.setVisibility(View.INVISIBLE);


                } else {
                    feedback.setVisibility(View.VISIBLE);
                    feedback.setText(myQuestionBank.get(questionNo).getExplaination());
                    wrong.setVisibility(View.VISIBLE);
                    next.setVisibility(View.VISIBLE);
                    ansA.setVisibility(View.INVISIBLE);
                    ansB.setVisibility(View.INVISIBLE);
                    ansC.setVisibility(View.INVISIBLE);
                    ansD.setVisibility(View.INVISIBLE);
                }
            }
        }); //end of option A listener

        ansB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myQuestionBank.get(questionNo).getAnswer().equals(ansB.getText().toString())) {
                    score += 10;
                    mark.setText(Integer.toString(score));
                    feedback.setVisibility(View.VISIBLE);
                    feedback.setText("Correct!!!");
                    correct.setVisibility(View.VISIBLE);
                    next.setVisibility(View.VISIBLE);
                    ansA.setVisibility(View.INVISIBLE);
                    ansB.setVisibility(View.INVISIBLE);
                    ansC.setVisibility(View.INVISIBLE);
                    ansD.setVisibility(View.INVISIBLE);


                } else {
                    feedback.setVisibility(View.VISIBLE);
                    feedback.setText(myQuestionBank.get(questionNo).getExplaination());
                    wrong.setVisibility(View.VISIBLE);
                    next.setVisibility(View.VISIBLE);
                    ansA.setVisibility(View.INVISIBLE);
                    ansB.setVisibility(View.INVISIBLE);
                    ansC.setVisibility(View.INVISIBLE);
                    ansD.setVisibility(View.INVISIBLE);
                }
            }
        }); //end of option B listener

        ansC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myQuestionBank.get(questionNo).getAnswer().equals(ansC.getText().toString())) {
                    score += 10;
                    mark.setText(Integer.toString(score));
                    feedback.setVisibility(View.VISIBLE);
                    feedback.setText("Correct!!!");
                    correct.setVisibility(View.VISIBLE);
                    next.setVisibility(View.VISIBLE);
                    ansA.setVisibility(View.INVISIBLE);
                    ansB.setVisibility(View.INVISIBLE);
                    ansC.setVisibility(View.INVISIBLE);
                    ansD.setVisibility(View.INVISIBLE);


                } else {
                    feedback.setVisibility(View.VISIBLE);
                    feedback.setText(myQuestionBank.get(questionNo).getExplaination());
                    wrong.setVisibility(View.VISIBLE);
                    next.setVisibility(View.VISIBLE);
                    ansA.setVisibility(View.INVISIBLE);
                    ansB.setVisibility(View.INVISIBLE);
                    ansC.setVisibility(View.INVISIBLE);
                    ansD.setVisibility(View.INVISIBLE);
                }
            }
        }); //end of option C listener

        ansD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myQuestionBank.get(questionNo).getAnswer().equals(ansD.getText().toString())) {
                    score += 10;
                    mark.setText(Integer.toString(score));
                    feedback.setVisibility(View.VISIBLE);
                    feedback.setText("Correct!!!");
                    correct.setVisibility(View.VISIBLE);
                    next.setVisibility(View.VISIBLE);
                    ansA.setVisibility(View.INVISIBLE);
                    ansB.setVisibility(View.INVISIBLE);
                    ansC.setVisibility(View.INVISIBLE);
                    ansD.setVisibility(View.INVISIBLE);


                } else {
                    feedback.setVisibility(View.VISIBLE);
                    feedback.setText(myQuestionBank.get(questionNo).getExplaination());
                    wrong.setVisibility(View.VISIBLE);
                    next.setVisibility(View.VISIBLE);
                    ansA.setVisibility(View.INVISIBLE);
                    ansB.setVisibility(View.INVISIBLE);
                    ansC.setVisibility(View.INVISIBLE);
                    ansD.setVisibility(View.INVISIBLE);
                }
            }
        }); //end of option A listener


        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                questionNo++;
                if(questionNo > 10) {
                    next.setVisibility(View.INVISIBLE);
                    feedback.setVisibility(View.INVISIBLE);
                    ansA.setVisibility(View.INVISIBLE);
                    ansB.setVisibility(View.INVISIBLE);
                    ansC.setVisibility(View.INVISIBLE);
                    ansD.setVisibility(View.INVISIBLE);
                    wrong.setVisibility(View.INVISIBLE);
                    correct.setVisibility(View.INVISIBLE);
                    question.setVisibility(View.VISIBLE);
                    end();
                }
                else{

                    question.setText(myQuestionBank.get(questionNo).getQuestion());
                    qno.setText(Integer.toString(questionNo));
                    next.setVisibility(View.INVISIBLE);
                    feedback.setVisibility(View.INVISIBLE);
                    ansA.setText(myQuestionBank.get(questionNo).getA());
                    ansA.setVisibility(View.VISIBLE);
                    ansB.setText(myQuestionBank.get(questionNo).getB());
                    ansB.setVisibility(View.VISIBLE);
                    ansC.setText(myQuestionBank.get(questionNo).getC());
                    ansC.setVisibility(View.VISIBLE);
                    ansD.setText(myQuestionBank.get(questionNo).getD());
                    ansD.setVisibility(View.VISIBLE);
                    wrong.setVisibility(View.INVISIBLE);
                    correct.setVisibility(View.INVISIBLE);
                    question.setVisibility(View.VISIBLE);

                    }
                }

        });

    }

//The following alert dialog code was referenced from the following youtube video:
    //https://www.youtube.com/watch?v=WpnM1BITW1Y
    //ARSL tech (2018)
    @Override
    public void onBackPressed() {
        AlertDialog.Builder warning = new AlertDialog.Builder(this);
        warning.setMessage("Exit with lose current progress");
        warning.setCancelable(false);
        warning.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
                QuizFundamental.super.onBackPressed();
            }
        });
        warning.setNegativeButton("Stay", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
               dialogInterface.cancel();
            }
        });
        warning.create().show();
    }
//

public void onContentIconClicked() {
    AlertDialog.Builder warning = new AlertDialog.Builder(this);
    warning.setMessage("Exit with lose current progress");
    warning.setCancelable(false);
    warning.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialogInterface, int i) {
            finish();
            intent = new Intent(getApplicationContext(),ContentAAMaster.class);
            startActivity(intent);
        }
    });
    warning.setNegativeButton("Stay", new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialogInterface, int i) {
            dialogInterface.cancel();
        }
    });
    warning.create().show();
}

    public void onSettingIconClicked() {
        AlertDialog.Builder warning = new AlertDialog.Builder(this);
        warning.setMessage("Exit with lose current progress");
        warning.setCancelable(false);
        warning.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
                intent = new Intent(getApplicationContext(),SettingAMaster.class);
                startActivity(intent);
            }
        });
        warning.setNegativeButton("Stay", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        warning.create().show();
    }

    public void onQuizIconClicked() {
        AlertDialog.Builder warning = new AlertDialog.Builder(this);
        warning.setMessage("Exit with lose current progress");
        warning.setCancelable(false);
        warning.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
                intent = new Intent(getApplicationContext(),QuizAMaster.class);
                startActivity(intent);
            }
        });
        warning.setNegativeButton("Stay", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        warning.create().show();
    }
    private void end(){

        result.setVisibility(View.VISIBLE);
        quitBtn.setVisibility(View.VISIBLE);
        if (score < 50)
            question.setText("Your total mark is " + score + ". FAIL. You need to work harder");
        else if (score < 65) {
            question.setText("Your total mark is " + score + ". PASS. Improve your understanding by going to content for revision");
        } else if (score < 75) {
            question.setText("Your total mark is " + score + ". Credit. Good job, keep going!");
        } else if (score < 85)
            question.setText("Your total mark is " + score + ". Distinction. Well done! You have great understanding of Java");
        else if (score < 100)
            question.setText("Your total mark is " + score + ". High Distinction. Excellent effort!!");

        else question.setText("You have scored an HD faultless. Congratulations~~ ");

        quitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent = new Intent(getApplicationContext(), QuizAMasterBranch.class);
                startActivity(intent);
            }
        });

    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.content:
                   //call method which will show an alert dialog
                   onContentIconClicked();

                    return true;


                case R.id.quiz:
                    //Toast display code referenced from following website:
                    //https://www.viralandroid.com/2015/09/android-toast-example.html
                    //Regmi,P 2018 "Android Toast - How to Display Simple Toast Message in Android"
                    Toast.makeText(getApplicationContext(), "Within a quiz already!", Toast.LENGTH_SHORT).show();
                    return true;
                case R.id.profile:

                    //call method which will show an alert dialog
                    onSettingIconClicked();
            }
            return false;
        }
    };


}

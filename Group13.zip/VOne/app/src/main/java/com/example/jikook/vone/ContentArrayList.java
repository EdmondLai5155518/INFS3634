package com.example.jikook.vone;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.BottomNavigationView;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;
import java.util.ArrayList;

//content material displayed in this class are referenced from:
// https://beginnersbook.com/2013/12/java-arraylist/
//author: CHAITANYA SINGH
//the youtube API code was referenced from Udemy, URL:
//https://www.udemy.com/master-android-7-nougat-java-app-development-step-by-step/learn/v4/t/lecture/5615180?start=0
//Author: Tim Buchalka

public class ContentArrayList extends YouTubeBaseActivity implements YouTubePlayer.OnInitializedListener {
    private final static String API_KEY = "AIzaSyBqhGQ6sNlUwE2E_ySTBtTvySqPe9ukNLI";
    private Intent intent;
    private TextView methods;

    //action if initialization is success. play video and display a success message toast
    @Override
    public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean wasRestored) {
        if (!wasRestored) {
            Toast.makeText(getApplicationContext(), "Video is loading! Please wait", Toast.LENGTH_SHORT).show();
            youTubePlayer.cueVideo("FhqdMFJbsxs");
        }
    }

    //action if initialization is failed. display a failure message
    @Override
    public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {
        Toast.makeText(getApplicationContext(), "Internet error!", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_arraylist);

        //Inflate the current layout with youtube player view
        ConstraintLayout layout = (ConstraintLayout) getLayoutInflater().inflate(R.layout.content_arraylist, null);
        setContentView(layout);
        YouTubePlayerView player = new YouTubePlayerView(this);
        player.setLayoutParams(new ConstraintLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        layout.addView(player);
        player.initialize(API_KEY, this);  //play the video using api key


        //following lines of code load the arraylist to the Listview
        ArrayList<String> arrayList = new ArrayList <String>();
        arrayList.add("Click to see Java Offical Documentation");
       methods = findViewById(R.id.methods);
        methods.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //intent direct user to a specified web page (Java documentation on arrayList)
                String url = "https://docs.oracle.com/javase/8/docs/api/java/util/ArrayList.html";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });

                BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        }//end of create

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.content:

                    intent = new Intent(getApplicationContext(),ContentAAMaster.class);
                startActivity(intent);
                    finish();
                return true;

                case R.id.quiz:
                    intent = new Intent(getApplicationContext(), QuizAMaster.class);
                    startActivity(intent);
                    finish();
                    return true;
                case R.id.profile:
                    intent = new Intent(getApplicationContext(), SettingAMaster.class);
                    startActivity(intent);
                    finish();
                    return true;
            }
            return false;
        }
    };

}



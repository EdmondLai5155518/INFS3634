package com.example.jikook.vone;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class SettingAMaster extends AppCompatActivity {
    private TextView mTextMessage;
    private LinearLayout email;
    private Intent intent;
    private LinearLayout share;
    private LinearLayout setting;
    private LinearLayout rate;
    private LinearLayout sign;
    private LinearLayout moreVideo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_page);

        moreVideo = findViewById(R.id.morevideo);
        moreVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //following code direct user to a Java programming youtube channel
                //Code referenced from stackoverflow
                //https://stackoverflow.com/questions/8840774/intent-to-youtube-app-profile-channel

                Intent intent=null;
                try {
                    intent =new Intent(Intent.ACTION_VIEW);
                    intent.setPackage("com.google.android.youtube");
                    intent.setData(Uri.parse("https://www.youtube.com/channel/UCs6nmQViDpUw0nuIx9c_WvA")); //youtube channel url
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse("https://www.youtube.com/channel/UCs6nmQViDpUw0nuIx9c_WvA"));
                    startActivity(intent);
                }
            }
        });

        mTextMessage = findViewById(R.id.username);  //update username if this activity is started by the FacebookLogin class
        intent = getIntent();
        String name = intent.getStringExtra("name"); //using getExtra to receive user name
        mTextMessage.setText(name);  //update text

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation_view);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        sign = findViewById(R.id.sign);  //if user click on batman figure, direct them to FacebookLogin class. See relevant class for actual logic.
        sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (getApplicationContext(),FacebookLogin.class);
                startActivity(intent);
            }
        });


         //this email intent note is referenced from StackOverFlow :
        //Post title: Send Email Intent
        // https://stackoverflow.com/questions/8701634/send-email-intent
        email = findViewById(R.id.email);
        email.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                        "mailto","m.cahalane@unsw.edu.au", null));  //putExtra - auto insert email address of LIC for user (UX)
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "INFS2605 learning app queries");  //help user to generate title of email (UX)
                emailIntent.putExtra(Intent.EXTRA_TEXT, "~Your question here~");
                startActivity(Intent.createChooser(emailIntent, "Choose an email application")); //tell user to choose an email application (normally, only email application shows up.)
            }
        });

        setting = findViewById(R.id.setting);  //direct user to a setting page
        setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),SettingPage.class);
                startActivity(intent);
            }
        });

        share = findViewById(R.id.share);
        //this sharing app intent is referenced from developer android
        //https://developer.android.com/training/sharing/send#java
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent shareApp = new Intent();
                shareApp.setAction(Intent.ACTION_SEND);
                //because the app is not upload to playstore, an sample ID of existing app is used.
                shareApp.putExtra(Intent.EXTRA_TEXT,
                        "Check this app out! Boost your INFS2605 marks! : https://play.google.com/store/apps/details?id=com.android.chrome");
                shareApp.setType("text/plain");
                startActivity(shareApp);
            }
        });

        //because the application is not upload to google playstore, the intent will only direct user to playstore for prototyping purpose
        rate = findViewById(R.id.rate);
        rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 String appPackageName = getPackageName();
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));

            }
        });
    }


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.content:
                intent = new Intent(getApplicationContext(),ContentAAMaster.class);
                startActivity(intent);
                finish();
                    return true;

                case R.id.quiz:
                intent = new Intent(getApplicationContext(),QuizAMaster.class);
                startActivity(intent);
                finish();
                return true;

                case R.id.profile:
                    Toast.makeText(getApplicationContext(), "Within setting already!", Toast.LENGTH_SHORT).show();
            }
            return false;
    };};


}





package com.example.jikook.vone;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewGroup;

import com.example.jikook.vone.ContentAAMaster;
import com.example.jikook.vone.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    //this class and its animation from referenced from the youtube video:
    //Angga, Risky (2018), UI Animation Login Screen Android Studio Tutorial
    //https://www.youtube.com/watch?v=JqPv4LZ53rU&index=84&list=PL6j62WXKkENq1pM1vqv1P9abb99ttMiIZ

    private ActivityMainBinding mBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mBinding= DataBindingUtil.setContentView(this,R.layout.activity_main);

    }
    public void load(View view){
        animateButtonWidth();
        fadeOutTestAndSetProgressDialog();
        nextAction();

    }
    private void animateButtonWidth(){
        ValueAnimator anim = ValueAnimator.ofInt(mBinding.signinBtn.getMeasuredWidth(),getFinalWidth());
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                int value  = (Integer) valueAnimator.getAnimatedValue();
                ViewGroup.LayoutParams layoutParams=mBinding.signinBtn.getLayoutParams();
                layoutParams.width=value;
                mBinding.signinBtn.requestLayout();
            }
        });
        anim.setDuration(125);
        anim.start();
    }
    private void fadeOutTestAndSetProgressDialog(){
        mBinding.signInText.animate().alpha(0f).setDuration(125).setListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                showProgressDialog();
            }
        }).start();
    }

    private void showProgressDialog(){
        mBinding.progressBar.getIndeterminateDrawable().setColorFilter(Color.parseColor("#8DC63F"), PorterDuff.Mode.SRC_IN);
        mBinding.progressBar.setVisibility(View.VISIBLE);

    }

    private void nextAction(){
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                revealButton();
                fadeOutProgressDialog();
                delayedStartNextActivity();

            }
        },1000);
    }

    private void revealButton(){
        mBinding.signinBtn.setElevation(0f);
        mBinding.revealView.setVisibility(View.VISIBLE);
        int x =mBinding.revealView.getWidth();
        int y =mBinding.revealView.getHeight();

        int startX = (int) (getFinalWidth()/2+mBinding.signinBtn.getX());
        int startY = (int) (getFinalWidth()/2+mBinding.signinBtn.getY());

        float radius = Math.max(x,y)*1.2f;
        Animator reveal = ViewAnimationUtils.createCircularReveal(mBinding.revealView,startX,startY,getFinalWidth(),radius);
        reveal.setDuration(350);
        reveal.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                finish();
            }
        });
        reveal.start();
    }

    private void fadeOutProgressDialog(){
        mBinding.progressBar.animate().alpha(0f).setDuration(200).start();
    }

    private void delayedStartNextActivity(){
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(MainActivity.this, ContentAAMaster.class));

            }
        },100);

    }
    private int getFinalWidth(){
        return(int)getResources().getDimension(R.dimen.get_width);
    }
}
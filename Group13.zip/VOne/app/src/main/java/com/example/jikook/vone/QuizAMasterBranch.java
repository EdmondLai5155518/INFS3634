package com.example.jikook.vone;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class QuizAMasterBranch extends AppCompatActivity {
//this is the sub page of MasterQuiz. Once user chose topic specific quiz, this class is invoked

    private Intent intent;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quizamasterbranch);

        //display a list of topic available for quiz using arraylist and arrayadapter
        //similiar to how MasterContentBranch class work
        //adding a list of topic into arrayList
        listView = findViewById(R.id.topicSelection);
        ArrayList<String> arrayList = new ArrayList <String>();
        arrayList.add("Week 1-2 Fundamentals");
        arrayList.add("Week 3 ArrayList (Release soon)");
        arrayList.add("Week 4 Exception");
        arrayList.add("Week 5 Design Principle (Release soon)");

       //load the arraylist in the adapter
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, arrayList);

        //set the adapter for listview (UI)
        listView.setAdapter(adapter);

        //define logic for when user clicks on to a certain topic, what happen
        //if topic is available, explicit intent is used to navigate to a specified class
        //otherwise toast message is given saying available soon
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                switch(position){
                    case 0:
                        Intent intent = new Intent(view.getContext(), QuizFundamental.class);
                        startActivity(intent);
                        break;

                    case 1:
                        Toast.makeText(getApplicationContext(),"Quiz will be available soon", Toast.LENGTH_SHORT).show();

                        break;

                    case 2:
                        Intent intentThree = new Intent(view.getContext(), QuizException.class);
                        startActivity(intentThree);
                        break;

                    case 3:
                        Toast.makeText(getApplicationContext(),"Quiz will be available soon", Toast.LENGTH_SHORT).show();
                         break;
                }};
        });

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.content:


                    intent = new Intent(getApplicationContext(),ContentAAMaster.class);
                    startActivity(intent);
                    finish();
                    return true;

                case R.id.quiz:

                    intent = new Intent (getApplicationContext(),QuizAMaster.class);
                    startActivity(intent);
                    finish();
                    return true;

                case R.id.profile:

                    intent = new Intent(getApplicationContext(),SettingAMaster.class);
                    startActivity(intent);
                    finish();
                    return true;
            }
            return false;
        }
    };


}




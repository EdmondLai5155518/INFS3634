package com.example.jikook.vone;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class StartingScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_starting_screen);
        Button startQuiz = findViewById(R.id.start); //if user click start, change to another new activity for quiz (see below intent)
        startQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startQuiz();
            }
        });

    }
    private void startQuiz(){
        Intent intent=new Intent(StartingScreenActivity.this,TimeSurivialQuiz.class);
        startActivity(intent);
    }
}

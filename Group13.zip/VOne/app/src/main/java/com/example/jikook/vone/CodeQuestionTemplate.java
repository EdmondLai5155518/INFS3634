package com.example.jikook.vone;

public class CodeQuestionTemplate {
    private int image;
    private String question;
    private String answer;
    private String explaination;

    //Constructor to create 'coding question' object
    CodeQuestionTemplate(int image, String question, String answer, String explaination) {
        this.image = image;
        this.question = question;
        this.answer = answer;
        this.explaination = explaination;
    }

    public String getExplaination() {
        return explaination;
    }

    public int getImage() {
        return image;
    }

    public String getQuestion() {
        return question;
    }

    public String getAnswer() {
        return answer;
    }

}



package com.example.jikook.vone;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

public class CodeQuestion extends AppCompatActivity {

private Intent intent;
private ArrayList<CodeQuestionTemplate> bank; //arraylist to store question object - CodeQuestionTemplate
private TextView questionRe; //display question and change to feedback when user submit answer
private ImageView codeseg;  //display code fragment
private EditText userans;   //where user enter their answer
private static int count;   //count the question number, terminates game when 5 questions been answered
private Button confirm;
private Button next;
private Button exitBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_code_question);

        //run time set up
        count = 0;
        codeseg = findViewById(R.id.codeseg);
        userans = findViewById(R.id.userans);
        questionRe = findViewById(R.id.questionRe);
        confirm = findViewById(R.id.confirmbtn);
        next = findViewById(R.id.next);
        exitBtn = findViewById(R.id.exitBtn);
        next.setVisibility(View.INVISIBLE);
        exitBtn.setVisibility(View.INVISIBLE);
        bank = new ArrayList<>();

        //input a range of question, by creating question object using the class - CodeQuestionTemplate
        //each object will have a code fragment image, question, expected answer and short explaination
        bank.add(new CodeQuestionTemplate(R.drawable.oop1,"What is the output of the following code","22","Incorrect! The age of Jimin is printed (22)."));
        bank.add(new CodeQuestionTemplate(R.drawable.oop2,"What is the output of the following code","e","Incorrect! There is no suitable constructor.Hence compile error."));
        bank.add(new CodeQuestionTemplate(R.drawable.oop3,"What is the output of the following code","Edmond","Incorrect! The superclass method getName method was invoked."));
        bank.add(new CodeQuestionTemplate(R.drawable.oop4,"What is the output of the following code","value","Incorrect! There is double quotation block on value, it was a String that got printed."));
        bank.add(new CodeQuestionTemplate(R.drawable.oop5,"What is the output of the following code","e","Incorrect! data is not initialized, causing compile error."));
        bank.add(new CodeQuestionTemplate(R.drawable.oop6,"What is the output of the following code","Exception","Incorrect! A number cannot be divided by 0."));
        bank.add(new CodeQuestionTemplate(R.drawable.oop7,"What is the output of the following code","e","Incorrect! Yolo is an abstract class, it cannot be instantiate."));
        bank.add(new CodeQuestionTemplate(R.drawable.oop8,"What is the output of the following code","OutOfBounds","Incorrect! a[6] is out of bounds as 5 was the max size declared."));
        bank.add(new CodeQuestionTemplate(R.drawable.oop9,"What is the output of the following code","LOL","Incorrect! The getName method in subclass is invoked as it overrides the superclass one"));
        bank.add(new CodeQuestionTemplate(R.drawable.oop10,"What is the output of the following code","32","Incorrect! myStudentTwo was removed."));
        bank.add(new CodeQuestionTemplate(R.drawable.oop11,"What is the output of the following code","e","Incorrect! The casting here is invalid, causing compile error. It should be (int)."));

        // Everytime when user start the game, the question display will be index 0 of the arraylist - bank.
        //Following code randomised the order of question.
        Collections.shuffle(bank);
        //Since the arraylist is shuffle, users get randomised questions everytime.


        //Alert pop up to notify users that they will have 5 random question everytime.
        AlertDialog.Builder warning = new AlertDialog.Builder(this);
        //message to display
        warning.setMessage("In this mode, you will be given 5 random code questions, instant feedback will be given");
        warning.setCancelable(false);
        warning.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();  //When user click ok, the dialog disappear
            }
        });
        warning.create().show();  //show the dialog

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        //set up initial question
        codeseg.setImageResource(bank.get(count).getImage());
        questionRe.setText(bank.get(count).getQuestion());

        //when user click confirm, their input in edittext is compared with answer -> using bank.get(index).getAnswer();
        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(count < 4) {
                    String temp = userans.getText().toString(); //getu user input

                    String ans = bank.get(count).getAnswer();  //get the current question answer

                    if (temp.equals(ans)) {   //compare userinput to the answer (String) using .equals
                        questionRe.setText("Correct!");
                    } else {
                        questionRe.setText(bank.get(count).getExplaination());  //if input is incorrect, explaination will show
                    }

                count++;

                next.setVisibility(View.VISIBLE);  //show the next button , its onclickListener is below
                confirm.setVisibility(View.INVISIBLE); // (UX) the confirm button disappear to avoid user accidentally click it two times
                    //the confirm button reappears when user move to next question

                }
                else{
                    //same as above code, except if count variable reaches to 4, then instead of the 'next' button,
                    //the exit button is shown.
                    String temp = userans.getText().toString();

                    String ans = bank.get(count).getAnswer();

                    if (temp.equals(ans)) {
                        questionRe.setText("Correct!");
                    } else {
                        questionRe.setText(bank.get(count).getExplaination());
                    }
                    count++;


                    confirm.setVisibility(View.INVISIBLE);
                    exitBtn.setVisibility(View.VISIBLE);
                }
            }
        });

        //this next onclickListener change the UI for next question
        //by setting new question and code fragment image, it also clears out the previous input (UX)
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    next.setVisibility(View.INVISIBLE);
                    confirm.setVisibility(View.VISIBLE);
                    userans.setText("");
                    codeseg.setImageResource(bank.get(count).getImage());
                    questionRe.setText(bank.get(count).getQuestion());

            }
        });

        //listener for exit button, go back to Quiz View, finish current activity
        exitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (getApplicationContext(),QuizAMaster.class);
                startActivity(intent);
                finish();
            }
        });
    }


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.content:
                    //call method which will show an alert dialog
                    //prevent user accidentally pressed the bottom navigation bar and lose progress
                    onContentIconClicked();
                    return true;

                case R.id.quiz:
                    //Toast display code referenced from following website:
                    //https://www.viralandroid.com/2015/09/android-toast-example.html
                    //Regmi,P 2018 "Android Toast - How to Display Simple Toast Message in Android"
                    Toast.makeText(getApplicationContext(), "Within a quiz already!", Toast.LENGTH_SHORT).show();
                    //if user click on the navigation quiz, a toast will be displayed to remind them they already in that section
                    return true;

                case R.id.profile:
                    //call method which will show an alert dialog
                    //prevent user accidentally pressed the bottom navigation bar and lose progress
                    onSettingIconClicked();
            }
            return false;
        }
    };


    //The following alert dialog code was referenced from the following youtube video:
    //https://www.youtube.com/watch?v=WpnM1BITW1Y
    //ARSL tech (2018)
    //The codes below are the actual methods for creating alert dialog (avoid user accidentally pressed something and lose progress)
    public void onContentIconClicked() {
        AlertDialog.Builder warning = new AlertDialog.Builder(this);  //create dialog object
        warning.setMessage("Exit with lose current progress");
        warning.setCancelable(false);
        warning.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
                intent = new Intent(getApplicationContext(),ContentAAMaster.class);  //if user confirm, goes to the desired activity
                startActivity(intent);
            }
        });
        warning.setNegativeButton("Stay", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        warning.create().show();
    }

    public void onSettingIconClicked() {
        AlertDialog.Builder warning = new AlertDialog.Builder(this);  //create dialog object
        warning.setMessage("Exit with lose current progress");
        warning.setCancelable(false);
        warning.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
                intent = new Intent(getApplicationContext(),SettingAMaster.class); //if user confirm, goes to desired activity
                startActivity(intent);
            }
        });
        warning.setNegativeButton("Stay", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        warning.create().show();
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder warning = new AlertDialog.Builder(this);  //create dialog object
        warning.setMessage("Exit with lose current progress");
        warning.setCancelable(false);
        warning.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
                CodeQuestion.super.onBackPressed();             //if user confirm, invoke backpress button
            }
        });
        warning.setNegativeButton("Stay", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        warning.create().show();
    }

}

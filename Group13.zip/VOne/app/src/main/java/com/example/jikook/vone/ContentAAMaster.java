package com.example.jikook.vone;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

public class ContentAAMaster extends AppCompatActivity {
//this is the master branch activity to display all learning material topic, then user can select to view a specific topic content

    //the listview and logo designed in this class was referenced from the following video
    // Angga, Risky (2018), Card List UI Design Animation - Android Studio Tutorial
    // https://www.youtube.com/watch?v=MpD7i3efk6A&list=PL6j62WXKkENq1pM1vqv1P9abb99ttMiIZ&index=87

    private Intent intent;
    private LinearLayout oop;
    private LinearLayout arrayList;
    private LinearLayout exception;
    private LinearLayout comingOne;
    private LinearLayout comingTwo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contentaamaster);

        //code below within onCreate are mainly used to create an onClickListener for each LinearLayout,
        //when user click on them, they are direct to another page that display the actual content by using explicit Intent

       oop = findViewById(R.id.fundamental);
       oop.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent intent = new Intent (getApplicationContext(),ContentRevision.class);
              startActivity(intent);
           }
       });

        arrayList = findViewById(R.id.arrayList);
        arrayList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (getApplicationContext(),ContentArrayList.class);
                startActivity(intent);
            }
        });

        exception = findViewById(R.id.exception);
        exception.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (getApplicationContext(),ContentException.class);
                startActivity(intent);
            }
        });

        //These two do not have intent, as these are material not yet available. Hence a toast is displayed
        comingOne = findViewById(R.id.comingOne);
        comingOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "To be released in week5 by LIC", Toast.LENGTH_SHORT).show();
            }
        });

        comingTwo = findViewById(R.id.comingTwo);
        comingTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "To be released in week6 by LIC", Toast.LENGTH_SHORT).show();
            }
        });

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation_view);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        //assign the bottom navigation bar to an onclick listen, based on which icon click,

    }
    //end of onCreate


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.content:
                    //because user already in the content page, no intent within this case block
                    //instead a message is displayed
                    Toast.makeText(getApplicationContext(), "Already in content page", Toast.LENGTH_SHORT).show();
                    //Toast display code referenced from following website:
                    //https://www.viralandroid.com/2015/09/android-toast-example.html
                    //Regmi,P 2018 "Android Toast - How to Display Simple Toast Message in Android", StackOverFlow
                    return true;

                case R.id.quiz:  //allow user to navigate to other section using explicit intent
                    intent = new Intent(getApplicationContext(), QuizAMaster.class);
                    startActivity(intent);
                    return true;

                case R.id.profile:  //allow user to navigate to other section using explicit intent
                    intent = new Intent(getApplicationContext(), SettingAMaster.class);
                    startActivity(intent);
                    return true;
            }
            return false;
        }
    };
}



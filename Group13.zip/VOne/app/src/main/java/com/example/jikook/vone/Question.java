package com.example.jikook.vone;

//class template for creating question objection in MCQS
public class Question {
    private String que;
    private String ans;
    private String explaination;
    private String a;
    private String b;
    private String c;
    private String d;

    Question(String que, String ans, String explaination, String a, String b, String c, String d) {
        this.ans = ans;
        this.que = que;
        this.explaination = explaination;
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;

    }

    public String getA() {
        return a;
    }

    public String getB() {
        return b;
    }

    public String getC() {
        return c;
    }

    public String getD() {
        return d;
    }

    public String getQuestion() {
        return que;
    }

    public String getAnswer() {
        return ans;
    }

    public String getExplaination() {
        return explaination;
    }
}

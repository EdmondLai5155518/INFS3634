package com.example.jikook.vone;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class QuizAMaster extends AppCompatActivity {
//this is the master page of quiz. the first page shows up when user click on the quiz icon at bottom
//this activity shows the available quiz mode for user (theory based, code based, time survival)
//there are three quiz mode, the time survival one is not finished
    private Intent intent;
    private ImageView  test;
    private ImageView generalTest;
    private ImageView  timeSurvival;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quiz_view);

        //following codes implement listener and intent to direct users to a specific page when icon is clicked

       test = findViewById(R.id.imageView);
       test.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               intent = new Intent (getApplicationContext(),QuizAMasterBranch.class);
               startActivity(intent);
           }
       });

       generalTest = findViewById(R.id.imageView3);
       generalTest.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        intent = new Intent (getApplicationContext(),CodeQuestion.class);
        startActivity(intent);
        }
         });

        timeSurvival = findViewById(R.id.imageView5);
        timeSurvival.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent (getApplicationContext(),StartingScreenActivity.class);
                startActivity(intent);
            }
        });

        BottomNavigationView navigation = findViewById(R.id.navigation_view);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

    }
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            switch (item.getItemId()) {
                case R.id.content:
                    intent = new Intent(getApplicationContext(), ContentAAMaster.class);
                    startActivity(intent);
                    finish();
                    return true;

                case R.id.quiz:

                    //Toast display code referenced from following website:
                    //https://www.viralandroid.com/2015/09/android-toast-example.html
                    //Regmi,P 2018 "Android Toast - How to Display Simple Toast Message in Android"
                    Toast.makeText(getApplicationContext(),"Already in quiz page", Toast.LENGTH_SHORT).show();
                    return true;
                case R.id.profile:
                    intent = new Intent(getApplicationContext(), SettingAMaster.class);
                    startActivity(intent);
                    finish();
                    return true;
            }
            return false;
        }
    };




}

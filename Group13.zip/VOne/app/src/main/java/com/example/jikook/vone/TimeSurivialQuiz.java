package com.example.jikook.vone;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.List;

public class TimeSurivialQuiz extends AppCompatActivity {
//still in development - concrete function not implemented
    //the time survival class is referenced from the following youtube video
    //Channel: Coding in Flow. (2018)
    // https://www.youtube.com/watch?v=pEDVdSUuWXE&pbjreload=10
    private TextView TextViewQuestion;
    private TextView TextViewScore;
    private TextView TextViewQuestionCount;
    private TextView TextViewCountDown;
    private RadioGroup rbGroup;
    private RadioButton bt1;
    private RadioButton bt2;
    private RadioButton bt3;
    private RadioButton bt4;
    private Button confirmButton;

    private List<Questions> questionsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_surivial_quiz);


        TextViewQuestion = findViewById(R.id.questions);
        TextViewScore = findViewById(R.id.score);
        TextViewQuestionCount = findViewById(R.id.question_count);
        TextViewCountDown =findViewById(R.id.coutdown);
        rbGroup = findViewById(R.id.radio_group);
        bt1=findViewById(R.id.option1);
        bt2=findViewById(R.id.option2);
        bt3=findViewById(R.id.option3);
        bt4=findViewById(R.id.option4);
        confirmButton = findViewById(R.id.confirm_next);

       // QuizDBHelper dbHelper = new QuizDBHelper(this);
       // questionsList = dbHelper.getAllQuestions();
    }
}

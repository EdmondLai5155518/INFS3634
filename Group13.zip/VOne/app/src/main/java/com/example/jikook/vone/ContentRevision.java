package com.example.jikook.vone;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.BottomNavigationView;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;


public class ContentRevision extends YouTubeBaseActivity implements YouTubePlayer.OnInitializedListener{
//display OOP content
//the youtube API code was referenced from Udemy, URL:
//https://www.udemy.com/master-android-7-nougat-java-app-development-step-by-step/learn/v4/t/lecture/5615180?start=0
//Author: Tim Buchalka
    public Intent intent;
    private final static String API_KEY = "AIzaSyBqhGQ6sNlUwE2E_ySTBtTvySqPe9ukNLI";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_revision);

        //Inflate the current layout with youtube player view
        ConstraintLayout layout = (ConstraintLayout) getLayoutInflater().inflate(R.layout.content_revision, null);
        setContentView(layout);
        YouTubePlayerView player = new YouTubePlayerView(this);
        player.setLayoutParams(new ConstraintLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        layout.addView(player);
        player.initialize(API_KEY, this);  //play the video using api key


        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }
    //action if initialization is success. play video and display a success message toast
    @Override
    public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean wasRestored) {
        if (!wasRestored) {
            Toast.makeText(getApplicationContext(), "Video is loading! Please wait", Toast.LENGTH_SHORT).show();
            youTubePlayer.cueVideo("pTB0EiLXUC8");
        }
    }
    //action if initialization is failed. display a failure message
    @Override
    public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {
        Toast.makeText(getApplicationContext(), "Internet error!", Toast.LENGTH_SHORT).show();
    }




    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.content:

                    intent = new Intent(getApplicationContext(),ContentAAMaster.class);
                    startActivity(intent);
                    finish();
                    return true;

                case R.id.quiz:
                    intent = new Intent(getApplicationContext(), QuizAMaster.class);
                    startActivity(intent);
                    finish();
                    return true;
                case R.id.profile:
                    intent = new Intent(getApplicationContext(), SettingAMaster.class);
                    startActivity(intent);
                    finish();
                    return true;
            }
            return false;
        }
    };

}

package com.example.jikook.vone;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

public class QuizException extends AppCompatActivity {

    TextView mark;  // display the current mark
    TextView question;  // /display the current question
    Button ansA; Button ansB; Button ansC; Button ansD;  //button for options
    Button next; //next question button
    Button quitBtn;  //return menu button to return to topic selection page
    Intent intent;
    TextView feedback; // display each question feedback
    TextView result; // used to display final result at the end
    TextView qno;   //keep track of question no.
    ImageView correct;
    ImageView wrong;
    ArrayList<Question> myQuestionBank;
    int score = 0;
    int questionNo = 1;

        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.mcq);
            BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
            navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
            result = findViewById(R.id.result);
            mark = findViewById(R.id.mark);
            feedback = findViewById(R.id.feedback);
            question = findViewById(R.id.questionBox);
            quitBtn = findViewById(R.id.quitBtn);
            quitBtn.setVisibility(View.INVISIBLE);
            next = findViewById(R.id.next);
            next.setVisibility(View.INVISIBLE);
            correct = findViewById(R.id.correct);
            correct.setVisibility(View.INVISIBLE);
            wrong = findViewById(R.id.wrong);
            wrong.setVisibility(View.INVISIBLE);
            qno = findViewById(R.id.qno);

            //creating a variable type of arraylist to be the question bank to store Question object
            myQuestionBank = new ArrayList();
            myQuestionBank.add(new Question("The parent class of error is ---?", "Throwable", "See Java Documentation","Object","Throwable","Exception","Collection"));
            myQuestionBank.add(new Question("An exception is a ---?", "Runtime error which can be managed", "Exception code is the block you specify how to deal with unexpected cases", "Runtime error","Compile time error","Runtime error which can be managed","Runtime error which can't be managed"));
            myQuestionBank.add(new Question("In Java, each exception is a member of which family?", "Throwable", "See Java Documentation", "Throwable","Runnable","Catchable","None of above"));
            myQuestionBank.add(new Question("ArithmeticException is a sub class of ---?","RuntimeException","See Java Documentation","Exception","RuntimeException","NumberException","IO Exception"));
            myQuestionBank.add(new Question("Can a try block has more than one catch blocks?", "Yes", "You can have multi-catch block! The first catch block that satisfies the condition will be executed", "Yes","No","",""));
            myQuestionBank.add(new Question("Can a try block be nested in another try block?", "Yes", "Nested try block will start executing from the outer block.", "Yes","No","",""));
            myQuestionBank.add(new Question("The subclass exception should precede the base class exception when used within the catch clause.", "True", "Should always start with most specific parameter and generalize", "True","False","",""));
            myQuestionBank.add(new Question("Which of the following is a checked exception?","Exception","Other exception will only be detected during runtime.","Exception","ArithmeticException","NullPointerException","NumberFormatException"));
            myQuestionBank.add(new Question("Which of the following keyword is the part of a method declaration?","throws", "throws is the correct answer.'throw' is used to throw custom exceptions","try", "catch", "throw","throws"));
            myQuestionBank.add(new Question("Can we define our own exceptions?","Yes","You can do so by creating a new class that extends 'Exception' class","Yes","No","",""));
            myQuestionBank.add(new Question("When a referenced class can't be loaded by the Java, which exception is thrown by it?", "NoClassDefFoundError", "See Java Documentation", "ClassNotFoundException","NoClassDefFoundError","NoSuchClassException",""));

            Collections.shuffle(myQuestionBank); //shuffle the question within arraylist, so user get random questions

            question.setText(myQuestionBank.get(questionNo).getQuestion());
            qno.setText(Integer.toString(questionNo));
            mark.setText(Integer.toString(score));
            ansA = findViewById(R.id.ansA);
            ansA.setText(myQuestionBank.get(questionNo).getA());
            ansB = findViewById(R.id.ansB);
            ansB.setText(myQuestionBank.get(questionNo).getB());
            ansC = findViewById(R.id.ansC);
            ansC.setText(myQuestionBank.get(questionNo).getC());
            ansD = findViewById(R.id.ansD);
            ansD.setText(myQuestionBank.get(questionNo).getD());
            //above codes are just all set up


            ansA.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //check for answer, if answer is correct increase score for ten and display correct
                    //otherwise display explaination
                    if (myQuestionBank.get(questionNo).getAnswer().equals(ansA.getText().toString())) {
                        score += 10;
                        mark.setText(Integer.toString(score));
                        feedback.setVisibility(View.VISIBLE);
                        feedback.setText("Correct!!!");
                        correct.setVisibility(View.VISIBLE);
                        next.setVisibility(View.VISIBLE);
                        ansA.setVisibility(View.INVISIBLE);
                        ansB.setVisibility(View.INVISIBLE);
                        ansC.setVisibility(View.INVISIBLE);
                        ansD.setVisibility(View.INVISIBLE);


                    } else {
                        feedback.setVisibility(View.VISIBLE);
                        feedback.setText(myQuestionBank.get(questionNo).getExplaination());
                        wrong.setVisibility(View.VISIBLE);
                        next.setVisibility(View.VISIBLE);
                        ansA.setVisibility(View.INVISIBLE);
                        ansB.setVisibility(View.INVISIBLE);
                        ansC.setVisibility(View.INVISIBLE);
                        ansD.setVisibility(View.INVISIBLE);
                    }
                }
            }); //end of option A listener

            ansB.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (myQuestionBank.get(questionNo).getAnswer().equals(ansB.getText().toString())) {
                        score += 10;
                        mark.setText(Integer.toString(score));
                        feedback.setVisibility(View.VISIBLE);
                        feedback.setText("Correct!!!");
                        correct.setVisibility(View.VISIBLE);
                        next.setVisibility(View.VISIBLE);
                        ansA.setVisibility(View.INVISIBLE);
                        ansB.setVisibility(View.INVISIBLE);
                        ansC.setVisibility(View.INVISIBLE);
                        ansD.setVisibility(View.INVISIBLE);


                    } else {
                        feedback.setVisibility(View.VISIBLE);
                        feedback.setText(myQuestionBank.get(questionNo).getExplaination());
                        wrong.setVisibility(View.VISIBLE);
                        next.setVisibility(View.VISIBLE);
                        ansA.setVisibility(View.INVISIBLE);
                        ansB.setVisibility(View.INVISIBLE);
                        ansC.setVisibility(View.INVISIBLE);
                        ansD.setVisibility(View.INVISIBLE);
                    }
                }
            }); //end of option B listener

            ansC.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (myQuestionBank.get(questionNo).getAnswer().equals(ansC.getText().toString())) {
                        score += 10;
                        mark.setText(Integer.toString(score));
                        feedback.setVisibility(View.VISIBLE);
                        feedback.setText("Correct!!!");
                        correct.setVisibility(View.VISIBLE);
                        next.setVisibility(View.VISIBLE);
                        ansA.setVisibility(View.INVISIBLE);
                        ansB.setVisibility(View.INVISIBLE);
                        ansC.setVisibility(View.INVISIBLE);
                        ansD.setVisibility(View.INVISIBLE);


                    } else {
                        feedback.setVisibility(View.VISIBLE);
                        feedback.setText(myQuestionBank.get(questionNo).getExplaination());
                        wrong.setVisibility(View.VISIBLE);
                        next.setVisibility(View.VISIBLE);
                        ansA.setVisibility(View.INVISIBLE);
                        ansB.setVisibility(View.INVISIBLE);
                        ansC.setVisibility(View.INVISIBLE);
                        ansD.setVisibility(View.INVISIBLE);
                    }
                }
            }); //end of option C listener

            ansD.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (myQuestionBank.get(questionNo).getAnswer().equals(ansD.getText().toString())) {
                        score += 10;
                        mark.setText(Integer.toString(score));
                        feedback.setVisibility(View.VISIBLE);
                        feedback.setText("Correct!!!");
                        correct.setVisibility(View.VISIBLE);
                        next.setVisibility(View.VISIBLE);
                        ansA.setVisibility(View.INVISIBLE);
                        ansB.setVisibility(View.INVISIBLE);
                        ansC.setVisibility(View.INVISIBLE);
                        ansD.setVisibility(View.INVISIBLE);


                    } else {
                        feedback.setVisibility(View.VISIBLE);
                        feedback.setText(myQuestionBank.get(questionNo).getExplaination());
                        wrong.setVisibility(View.VISIBLE);
                        next.setVisibility(View.VISIBLE);
                        ansA.setVisibility(View.INVISIBLE);
                        ansB.setVisibility(View.INVISIBLE);
                        ansC.setVisibility(View.INVISIBLE);
                        ansD.setVisibility(View.INVISIBLE);
                    }
                }
            }); //end of option A listener


            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    questionNo++;  //update question counter
                    if(questionNo > 10) {
                        next.setVisibility(View.INVISIBLE);
                        feedback.setVisibility(View.INVISIBLE);
                        ansA.setVisibility(View.INVISIBLE);
                        ansB.setVisibility(View.INVISIBLE);
                        ansC.setVisibility(View.INVISIBLE);
                        ansD.setVisibility(View.INVISIBLE);
                        wrong.setVisibility(View.INVISIBLE);
                        correct.setVisibility(View.INVISIBLE);
                        question.setVisibility(View.VISIBLE);
                        end(); //calling this method when user reaches question 10, final comment and grade is given
                    }
                    else{
                        //update question and available options
                        question.setText(myQuestionBank.get(questionNo).getQuestion());
                        qno.setText(Integer.toString(questionNo));
                        next.setVisibility(View.INVISIBLE);
                        feedback.setVisibility(View.INVISIBLE);
                        ansA.setText(myQuestionBank.get(questionNo).getA());
                        ansA.setVisibility(View.VISIBLE);
                        ansB.setText(myQuestionBank.get(questionNo).getB());
                        ansB.setVisibility(View.VISIBLE);
                        ansC.setText(myQuestionBank.get(questionNo).getC());
                        ansC.setVisibility(View.VISIBLE);
                        ansD.setText(myQuestionBank.get(questionNo).getD());
                        ansD.setVisibility(View.VISIBLE);
                        wrong.setVisibility(View.INVISIBLE);
                        correct.setVisibility(View.INVISIBLE);
                        question.setVisibility(View.VISIBLE);

                    }
                }

            });

        }

        //The following alert dialog code was referenced from the following youtube video:
        //https://www.youtube.com/watch?v=WpnM1BITW1Y
        //ARSL tech (2018)
        @Override
        public void onBackPressed() {
            AlertDialog.Builder warning = new AlertDialog.Builder(this);
            warning.setMessage("Exit with lose current progress");
            warning.setCancelable(false);
            warning.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                    QuizException.super.onBackPressed();

                }
            });
            warning.setNegativeButton("Stay", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.cancel();
                }
            });
            warning.create().show();
        }
//

        public void onContentIconClicked() {
            AlertDialog.Builder warning = new AlertDialog.Builder(this);
            warning.setMessage("Exit with lose current progress");
            warning.setCancelable(false);
            warning.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                    intent = new Intent(getApplicationContext(),ContentAAMaster.class);
                    startActivity(intent);
                }
            });
            warning.setNegativeButton("Stay", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.cancel();
                }
            });
            warning.create().show();
        }

        public void onSettingIconClicked() {
            AlertDialog.Builder warning = new AlertDialog.Builder(this);
            warning.setMessage("Exit with lose current progress");
            warning.setCancelable(false);
            warning.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                    intent = new Intent(getApplicationContext(),SettingAMaster.class);
                    startActivity(intent);
                }
            });
            warning.setNegativeButton("Stay", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.cancel();
                }
            });
            warning.create().show();
        }

        public void onQuizIconClicked() {
            AlertDialog.Builder warning = new AlertDialog.Builder(this);
            warning.setMessage("Exit with lose current progress");
            warning.setCancelable(false);
            warning.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                    intent = new Intent(getApplicationContext(),QuizAMaster.class);
                    startActivity(intent);
                }
            });
            warning.setNegativeButton("Stay", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.cancel();
                }
            });
            warning.create().show();
        }
        private void end(){
            //this method only called when user finish all 10 questions. Giving a final grade.
            result.setVisibility(View.VISIBLE);
            quitBtn.setVisibility(View.VISIBLE); //make the exit button visible.
            if (score < 50)
                question.setText("Your total mark is " + score + ". FAIL. You need to work harder");
            else if (score < 65) {
                question.setText("Your total mark is " + score + ". PASS. Improve your understanding by going to content for revision");
            } else if (score < 75) {
                question.setText("Your total mark is " + score + ". Credit. Good job, keep going!");
            } else if (score < 85)
                question.setText("Your total mark is " + score + ". Distinction. Well done! You have great understanding of Java");
            else if (score < 100)
                question.setText("Your total mark is " + score + ". High Distinction. Excellent effort!!");

            else question.setText("You have scored an HD faultless. Congratulations~~ ");

            //user going back to original quiz view page.
            quitBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    intent = new Intent(getApplicationContext(), QuizAMasterBranch.class);
                    startActivity(intent);
                }
            });

        }

        private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
                = new BottomNavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.content:
                        //call method which will show an alert dialog
                        onContentIconClicked();

                        return true;


                    case R.id.quiz:
                        //Toast display code referenced from following website:
                        //https://www.viralandroid.com/2015/09/android-toast-example.html
                        //Regmi,P 2018 "Android Toast - How to Display Simple Toast Message in Android"
                        Toast.makeText(getApplicationContext(), "Within a quiz already!", Toast.LENGTH_SHORT).show();
                        return true;
                    case R.id.profile:

                        //call method which will show an alert dialog
                        onSettingIconClicked();
                }
                return false;
            }
        };


    }



package com.example.jikook.vone;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import org.json.JSONException;
import org.json.JSONObject;
//this class is referenced from youtube video series:
//Tech Academy (2017)
//https://www.youtube.com/watch?v=v1Of93p-Drs
public class FacebookLogin extends AppCompatActivity {
    LoginButton loginButton;
    CallbackManager callbackManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_register);

        //logic for getting facebook image back to app
        loginButton = (LoginButton)findViewById(R.id.fblogin_btn);
        loginButton.setReadPermissions("public_profile");
        callbackManager = CallbackManager.Factory.create();
        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() { //calling facebook api
            @Override
            public void onSuccess(LoginResult loginResult) {  //if login in success
                String uerId = loginResult.getAccessToken().getUserId();
                GraphRequest graphRequest = GraphRequest.newMeRequest(loginResult.getAccessToken(), new GraphRequest.GraphJSONObjectCallback() {
                    @Override
                    public void onCompleted(JSONObject object, GraphResponse response) {
                     displayUserInfo(object); //call the method and return username through intent putExtra to profile page
                    }
                });
                Bundle parameters = new Bundle();
                parameters.putString("fields","first_name,last_name,id");
                graphRequest.setParameters(parameters);
                graphRequest.executeAsync();
            }

            @Override
            public void onCancel() {

            }

            @Override
            public void onError(FacebookException error) {

            }
        });


    }
    public void displayUserInfo(JSONObject object){
        String first_name,last_name;
        first_name = "";
        last_name = "";
        try {
            first_name = object.getString("first_name");
            last_name = object.getString("last_name");

        } catch (JSONException e) {
            e.printStackTrace();
        }
        Intent intent = new Intent(getApplicationContext(),SettingAMaster.class);
        intent.putExtra("name",first_name + " " + last_name);
        startActivity(intent);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
    }
    }





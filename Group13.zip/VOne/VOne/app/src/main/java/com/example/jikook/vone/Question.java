package com.example.jikook.vone;

public class Question {
    private String que;
    private String ans;
    private String explaination;

    Question(String que, String ans, String explaination) {
        this.ans = ans;
        this.que = que;
        this.explaination = explaination;

    }

    public String getQuestion() {
        return que;
    }

    public String getAnswer() {
        return ans;
    }

    public String getExplaination() {
        return explaination;
    }
}

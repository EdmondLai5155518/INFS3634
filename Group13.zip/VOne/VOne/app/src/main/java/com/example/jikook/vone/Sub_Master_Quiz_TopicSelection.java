package com.example.jikook.vone;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Sub_Master_Quiz_TopicSelection extends AppCompatActivity {
//this is the sub page of MasterQuiz. Once user chose topic specific quiz, this class is invoked

    private Intent intent;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quiz_exam_topic_selection);

        //display a list of topic available for quiz using arraylist and arrayadapter
        //similiar to how MasterContentBranch class work
        listView = findViewById(R.id.topicSelection);
        ArrayList<String> arrayList = new ArrayList <String>();
        arrayList.add("Week 1-2 Fundamentals");
        arrayList.add("Week 3-4 JavaFx");
        arrayList.add("Week 5 Exception");


        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, arrayList);

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                switch(position){
                    case 0:
                        Intent intent = new Intent(view.getContext(), FundamentalQuiz.class);
                        startActivity(intent);
                        break;

                    case 1:

                        break;

                }};
        });

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_content:

                    //warning pop up, if click, user lose current progress
                    finish();
                    return true;

                case R.id.navigation_quiz:
                    //Toast display code referenced from following website:
                    //https://www.viralandroid.com/2015/09/android-toast-example.html
                    //Regmi,P 2018 "Android Toast - How to Display Simple Toast Message in Android"
                    Toast.makeText(getApplicationContext(),"Already in quiz mode", Toast.LENGTH_SHORT).show();
                    return true;

                case R.id.navigation_settings:

                    //warning pop up, if click, user lose current progress
                    finish();
                    return true;
            }
            return false;
        }
    };


}




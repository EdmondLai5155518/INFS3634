package com.example.jikook.vone;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class FundamentalQuiz extends AppCompatActivity {
    //this is the actual quiz class (topic 1 - fundamental)

    TextView mark;  // display the current mark
    TextView question;  // /display the current question
    Button ansA; Button ansB; Button ansC; Button ansD;  //button for options
    Button next; //next question button
    Button quitBtn;  //return menu button to return to topic selection page
    Intent intent;
    TextView feedback; // display each question feedback
    TextView result; // used to display final result at the end
    TextView qno;   //keep track of question no.
    ImageView correct;
    ImageView wrong;
    ArrayList<Question> myQuestionBank;
    int score = 0;
    int questionNo = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fundamental_quiz);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        result = findViewById(R.id.result);
        mark = findViewById(R.id.mark);
        feedback = findViewById(R.id.feedback);
        question = findViewById(R.id.questionBox);
        quitBtn = findViewById(R.id.quitBtn);
        quitBtn.setVisibility(View.INVISIBLE);
        next = findViewById(R.id.next);
        next.setVisibility(View.INVISIBLE);
        correct = findViewById(R.id.correct);
        correct.setVisibility(View.INVISIBLE);
        wrong = findViewById(R.id.wrong);
        wrong.setVisibility(View.INVISIBLE);
        qno = findViewById(R.id.qno);
        ansA = findViewById(R.id.ansA);
        ansA.setText("A");
        ansB = findViewById(R.id.ansB);
        ansB.setText("B");
        ansC = findViewById(R.id.ansC);
        ansC.setText("C");
        ansD = findViewById(R.id.ansD);
        ansD.setText("D");
         //above codes are just all set up

        myQuestionBank = new ArrayList();
        myQuestionBank.add(new Question("Dummy", "Dummy", "Dummy"));
        myQuestionBank.add(new Question("Click A for correct", "A", "INCORRECT!! Because it is A"));
        myQuestionBank.add(new Question("Click B for correct", "B", "INCORRECT!! Because it is B"));
        myQuestionBank.add(new Question("Click C for correct", "C", "INCORRECT!! Because it is C"));
        myQuestionBank.add(new Question("Click D for correct", "D", "INCORRECT!! Because it is D"));
        myQuestionBank.add(new Question("Click A for correct", "A", "INCORRECT!! Because it is A"));
        myQuestionBank.add(new Question("Click B for correct", "B", "INCORRECT!! Because it is B"));
        myQuestionBank.add(new Question("Click C for correct", "C", "INCORRECT!! Because it is C"));
        myQuestionBank.add(new Question("Click D for correct", "D", "INCORRECT!! Because it is D"));
        myQuestionBank.add(new Question("Click A for correct", "A", "INCORRECT!! Because it is A"));
        myQuestionBank.add(new Question("Click B for correct", "B", "INCORRECT!! Because it is B"));

        question.setText(myQuestionBank.get(questionNo).getQuestion());
        qno.setText(Integer.toString(questionNo));
        mark.setText(Integer.toString(score));


        ansA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myQuestionBank.get(questionNo).getAnswer().equals("A")) {
                    score += 10;
                    mark.setText(Integer.toString(score));
                    feedback.setVisibility(View.VISIBLE);
                    feedback.setText("Correct!!!");
                    correct.setVisibility(View.VISIBLE);
                    next.setVisibility(View.VISIBLE);
                    ansA.setVisibility(View.INVISIBLE);
                    ansB.setVisibility(View.INVISIBLE);
                    ansC.setVisibility(View.INVISIBLE);
                    ansD.setVisibility(View.INVISIBLE);

                } else {
                    feedback.setVisibility(View.VISIBLE);
                    feedback.setText(myQuestionBank.get(questionNo).getExplaination());
                    wrong.setVisibility(View.VISIBLE);
                    next.setVisibility(View.VISIBLE);
                    ansA.setVisibility(View.INVISIBLE);
                    ansB.setVisibility(View.INVISIBLE);
                    ansC.setVisibility(View.INVISIBLE);
                    ansD.setVisibility(View.INVISIBLE);
                }
            }
        }); //end of option A listener

        ansB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myQuestionBank.get(questionNo).getAnswer().equals("B")) {
                    score += 10;
                    mark.setText(Integer.toString(score));
                    feedback.setVisibility(View.VISIBLE);
                    feedback.setText("Correct!!!");
                    correct.setVisibility(View.VISIBLE);
                    next.setVisibility(View.VISIBLE);
                    ansA.setVisibility(View.INVISIBLE);
                    ansB.setVisibility(View.INVISIBLE);
                    ansC.setVisibility(View.INVISIBLE);
                    ansD.setVisibility(View.INVISIBLE);

                } else {
                    feedback.setVisibility(View.VISIBLE);
                    feedback.setText(myQuestionBank.get(questionNo).getExplaination());
                    wrong.setVisibility(View.VISIBLE);
                    next.setVisibility(View.VISIBLE);
                    ansA.setVisibility(View.INVISIBLE);
                    ansB.setVisibility(View.INVISIBLE);
                    ansC.setVisibility(View.INVISIBLE);
                    ansD.setVisibility(View.INVISIBLE);
                }
            }
        }); //end of option B listener

        ansC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myQuestionBank.get(questionNo).getAnswer().equals("C")) {
                    score += 10;
                    mark.setText(Integer.toString(score));
                    feedback.setVisibility(View.VISIBLE);
                    feedback.setText("Correct!!!");
                    correct.setVisibility(View.VISIBLE);
                    next.setVisibility(View.VISIBLE);
                    ansA.setVisibility(View.INVISIBLE);
                    ansB.setVisibility(View.INVISIBLE);
                    ansC.setVisibility(View.INVISIBLE);
                    ansD.setVisibility(View.INVISIBLE);

                } else {
                    feedback.setVisibility(View.VISIBLE);
                    feedback.setText(myQuestionBank.get(questionNo).getExplaination());
                    wrong.setVisibility(View.VISIBLE);
                    next.setVisibility(View.VISIBLE);
                    ansA.setVisibility(View.INVISIBLE);
                    ansB.setVisibility(View.INVISIBLE);
                    ansC.setVisibility(View.INVISIBLE);
                    ansD.setVisibility(View.INVISIBLE);
                }
            }
        }); //end of option C listener

        ansD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (myQuestionBank.get(questionNo).getAnswer().equals("D")) {
                    score += 10;
                    mark.setText(Integer.toString(score));
                    feedback.setVisibility(View.VISIBLE);
                    feedback.setText("Correct!!!");
                    correct.setVisibility(View.VISIBLE);
                    next.setVisibility(View.VISIBLE);
                    ansA.setVisibility(View.INVISIBLE);
                    ansB.setVisibility(View.INVISIBLE);
                    ansC.setVisibility(View.INVISIBLE);
                    ansD.setVisibility(View.INVISIBLE);

                } else {
                    feedback.setVisibility(View.VISIBLE);
                    feedback.setText(myQuestionBank.get(questionNo).getExplaination());
                    wrong.setVisibility(View.VISIBLE);
                    next.setVisibility(View.VISIBLE);
                    ansA.setVisibility(View.INVISIBLE);
                    ansB.setVisibility(View.INVISIBLE);
                    ansC.setVisibility(View.INVISIBLE);
                    ansD.setVisibility(View.INVISIBLE);
                }
            }
        }); //end of option D listener


        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                questionNo++;
                if(questionNo > 10) {
                    next.setVisibility(View.INVISIBLE);
                    feedback.setVisibility(View.INVISIBLE);
                    ansA.setVisibility(View.INVISIBLE);
                    ansB.setVisibility(View.INVISIBLE);
                    ansC.setVisibility(View.INVISIBLE);
                    ansD.setVisibility(View.INVISIBLE);
                    wrong.setVisibility(View.INVISIBLE);
                    correct.setVisibility(View.INVISIBLE);
                    end();
                }
                else{

                    question.setText(myQuestionBank.get(questionNo).getQuestion());
                    qno.setText(Integer.toString(questionNo));
                    next.setVisibility(View.INVISIBLE);
                    feedback.setVisibility(View.INVISIBLE);
                    ansA.setVisibility(View.VISIBLE);
                    ansB.setVisibility(View.VISIBLE);
                    ansC.setVisibility(View.VISIBLE);
                    ansD.setVisibility(View.VISIBLE);
                    wrong.setVisibility(View.INVISIBLE);
                    correct.setVisibility(View.INVISIBLE);

                    }
                }

        });

    }

    private void end(){

        result.setVisibility(View.VISIBLE);
        quitBtn.setVisibility(View.VISIBLE);
        if (score < 50)
            question.setText("Your total mark is " + score + ". FAIL");
        else if (score < 65) {
            question.setText("Your total mark is " + score + ". PASS");
        } else if (score < 75) {
            question.setText("Your total mark is " + score + ". Credit");
        } else if (score < 85)
            question.setText("Your total mark is " + score + ". Distinction");
        else if (score < 100)
            question.setText("Your total mark is " + score + ". High Distinction");

        else question.setText("You have scored an HD faultless.");

        quitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent = new Intent(getApplicationContext(), Sub_Master_Quiz_TopicSelection.class);
                startActivity(intent);
            }
        });

    }

    //dont tamper code below unless for the pop up warning

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_content:

                    //warning pop up, if click, execute code below and user lose current progress

                    intent = new Intent(getApplicationContext(),MasterContentBranch.class);
                    startActivity(intent);

                    return true;


                case R.id.navigation_quiz:
                    //Toast display code referenced from following website:
                    //https://www.viralandroid.com/2015/09/android-toast-example.html
                    //Regmi,P 2018 "Android Toast - How to Display Simple Toast Message in Android"
                    Toast.makeText(getApplicationContext(), "Within a quiz already!", Toast.LENGTH_SHORT).show();
                    return true;
                case R.id.navigation_settings:
//warning pop up, if click, execute code below and user lose current progress

                    intent = new Intent(getApplicationContext(),SettingMaster.class);
                    startActivity(intent);

                    return true;
            }
            return false;
        }
    };
}

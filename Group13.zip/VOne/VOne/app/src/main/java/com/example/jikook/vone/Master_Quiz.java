package com.example.jikook.vone;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Master_Quiz extends AppCompatActivity {
//this is the master page of quiz. the first page shows up when user click on the quiz icon at bottom

    private Intent intent;
    private Intent directIntent;
    private Button btnDirectToSpecific;  //button direct to topic specific quiz mode
    private Button survival;   //button direct to survival mode (like life game)
    private Button race;       //button directs to race mode. (time limit with randomised question)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quizmaster);

        //implementing the first button listener
        btnDirectToSpecific = findViewById(R.id.specificQuiz);
        btnDirectToSpecific.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                directIntent = new Intent (getApplicationContext(),Sub_Master_Quiz_TopicSelection.class);
                startActivity(directIntent);
            }});

        //implement the survival button

        //implement the race button

        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);


    }
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            switch (item.getItemId()) {
                case R.id.navigation_content:
                    intent = new Intent(getApplicationContext(), MasterContentBranch.class);
                    startActivity(intent);
                    finish();
                    return true;

                case R.id.navigation_quiz:

                    //Toast display code referenced from following website:
                    //https://www.viralandroid.com/2015/09/android-toast-example.html
                    //Regmi,P 2018 "Android Toast - How to Display Simple Toast Message in Android"
                    Toast.makeText(getApplicationContext(),"Already in quiz page", Toast.LENGTH_SHORT).show();
                    return true;
                case R.id.navigation_settings:
                    intent = new Intent(getApplicationContext(), SettingMaster.class);
                    startActivity(intent);
                    finish();
                    return true;
            }
            return false;
        }
    };




}

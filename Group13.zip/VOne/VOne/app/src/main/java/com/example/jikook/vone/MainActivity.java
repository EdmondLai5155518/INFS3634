package com.example.jikook.vone;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private Intent intent;
    private EditText userNameInput;
    private ConstraintLayout cl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainactivity);

        userNameInput = findViewById(R.id.editText);   //capture user name input at home page.
        // the value is currently not used in anywhere, later should  implement an intent,etc.

        cl = findViewById(R.id.mainlayout);  //change the colour of background by altering constraint layout
        cl.setBackgroundColor(Color.WHITE); //can reuse in other activities

        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        //assign the bottom navigation bar to an onclick listen, based on which icon click,
        //jump to a different activity (intent), might pass on some parameters in some case

        InputMethodManager manager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        manager.hideSoftInputFromWindow(userNameInput.getWindowToken(), 0);
        //the above two lines set the keyboard to disappear once user click ok after entering name in editText
        //Champion, N. 2011 "After type in EditText, how to make keyboard disappear", StackOverFlow
        //https://stackoverflow.com/questions/4841228/after-type-in-edittext-how-to-make-keyboard-disappear
    } //end of OnCreate



     //creating onclick listener specifically for BottomNavigationView widget
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                //depends on which icon is clicked, the correspond case statement will be executed
                //and jump to a specific activity(explicit)
                case R.id.navigation_content:
                    intent = new Intent(getApplicationContext(),MasterContentBranch.class);
                    startActivity(intent);
                    return true;

                case R.id.navigation_quiz:
                    intent = new Intent(getApplicationContext(),Master_Quiz.class);
                    startActivity(intent);
                    return true;

                case R.id.navigation_settings:
                    intent = new Intent(getApplicationContext(),SettingMaster.class);
                    startActivity(intent);
                    return true;
            }
            return false;
        }
    };

}
